import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import axios from 'axios';

interface User {
  user_id: string;
  user_name: string;
  user_shortname: string;
  user_type: string;
  avatar_url?: string;
  broker: string;
  exchanges: string[];
  products: string[];
  order_types: string[];
}

interface AuthContextType {
  user: User | null;
  accessToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (requestToken: string) => Promise<void>;
  logout: () => Promise<void>;
  getLoginUrl: () => Promise<string>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Axios instance with base configuration
const api = axios.create({
  baseURL: 'http://localhost:3000/api',
  timeout: 10000,
});

// Add request interceptor to include auth token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('accessToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Add response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('accessToken');
      localStorage.removeItem('userData');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const isAuthenticated = !!accessToken && !!user;

  useEffect(() => {
    // Check for stored auth data on component mount
    const storedToken = localStorage.getItem('accessToken');
    const storedUser = localStorage.getItem('userData');

    if (storedToken && storedUser) {
      try {
        const userData = JSON.parse(storedUser);
        setAccessToken(storedToken);
        setUser(userData);
      } catch (error) {
        console.error('Error parsing stored user data:', error);
        localStorage.removeItem('accessToken');
        localStorage.removeItem('userData');
      }
    }
    setIsLoading(false);
  }, []);

  const getLoginUrl = async (): Promise<string> => {
    try {
      const response = await api.get('/auth/login-url');
      return response.data.data.login_url;
    } catch (error) {
      console.error('Error getting login URL:', error);
      throw new Error('Failed to get login URL');
    }
  };

  const login = async (requestToken: string): Promise<void> => {
    try {
      setIsLoading(true);
      const response = await api.post('/auth/login', {
        request_token: requestToken,
      });

      const { data } = response.data;
      
      const userData: User = {
        user_id: data.user_id,
        user_name: data.user_name,
        user_shortname: data.user_shortname,
        user_type: data.user_type,
        avatar_url: data.avatar_url,
        broker: data.broker,
        exchanges: data.exchanges,
        products: data.products,
        order_types: data.order_types,
      };

      // Store auth data
      localStorage.setItem('accessToken', data.access_token);
      localStorage.setItem('userData', JSON.stringify(userData));

      setAccessToken(data.access_token);
      setUser(userData);
    } catch (error) {
      console.error('Login error:', error);
      throw new Error('Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      // Call logout API
      await api.post('/auth/logout');
    } catch (error) {
      console.error('Logout error:', error);
      // Continue with local logout even if API call fails
    } finally {
      // Clear auth data
      localStorage.removeItem('accessToken');
      localStorage.removeItem('userData');
      setAccessToken(null);
      setUser(null);
    }
  };

  const value: AuthContextType = {
    user,
    accessToken,
    isAuthenticated,
    isLoading,
    login,
    logout,
    getLoginUrl,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Export the api instance for use in other components
export { api };
