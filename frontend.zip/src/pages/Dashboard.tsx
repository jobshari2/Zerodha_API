import React from 'react';
import {
  Box,
  Drawer,
  AppBar,
  Toolbar,
  List,
  Typography,
  Divider,
  IconButton,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Avatar,
  Button,
} from '@mui/material';
import {
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  AccountBalance as HoldingsIcon,
  Timeline as ChartsIcon,
  GetApp as DownloadIcon,
  Logout as LogoutIcon,
  TrendingUp,
} from '@mui/icons-material';
import { styled } from '@mui/material/styles';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const drawerWidth = 240;

const Main = styled('main', { shouldForwardProp: (prop) => prop !== 'open' })<{
  open?: boolean;
}>(({ theme, open }) => ({
  flexGrow: 1,
  padding: theme.spacing(3),
  transition: theme.transitions.create('margin', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  marginLeft: `-${drawerWidth}px`,
  ...(open && {
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
    marginLeft: 0,
  }),
}));

const AppBarStyled = styled(AppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})<{ open?: boolean }>(({ theme, open }) => ({
  transition: theme.transitions.create(['margin', 'width'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    width: `calc(100% - ${drawerWidth}px)`,
    marginLeft: `${drawerWidth}px`,
    transition: theme.transitions.create(['margin', 'width'], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
  justifyContent: 'flex-end',
}));

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();
  const [open, setOpen] = React.useState(true);

  const handleDrawerToggle = () => {
    setOpen(!open);
  };

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const menuItems = [
    {
      text: 'Dashboard',
      icon: <DashboardIcon />,
      path: '/dashboard',
    },
    {
      text: 'Holdings',
      icon: <HoldingsIcon />,
      path: '/holdings',
    },
    {
      text: 'Charts',
      icon: <ChartsIcon />,
      path: '/charts',
    },
    {
      text: 'Historical Data',
      icon: <DownloadIcon />,
      path: '/historical-data',
    },
  ];

  return (
    <Box sx={{ display: 'flex' }}>
      <AppBarStyled position="fixed" open={open}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerToggle}
            edge="start"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <TrendingUp sx={{ mr: 2 }} />
          <Typography variant="h6" noWrap component="div" sx={{ flexGrow: 1 }}>
            Zerodha Kite API
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Typography variant="body2">
              {user?.user_shortname || user?.user_name}
            </Typography>
            <Avatar sx={{ width: 32, height: 32 }}>
              {user?.user_shortname?.charAt(0) || user?.user_name?.charAt(0) || 'U'}
            </Avatar>
            <Button
              color="inherit"
              onClick={handleLogout}
              startIcon={<LogoutIcon />}
            >
              Logout
            </Button>
          </Box>
        </Toolbar>
      </AppBarStyled>
      
      <Drawer
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box',
          },
        }}
        variant="persistent"
        anchor="left"
        open={open}
      >
        <DrawerHeader>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mr: 'auto', ml: 2 }}>
            <TrendingUp color="primary" />
            <Typography variant="h6" color="primary">
              Kite API
            </Typography>
          </Box>
        </DrawerHeader>
        <Divider />
        <List>
          {menuItems.map((item) => (
            <ListItem key={item.text} disablePadding>
              <ListItemButton
                selected={location.pathname === item.path}
                onClick={() => navigate(item.path)}
              >
                <ListItemIcon>{item.icon}</ListItemIcon>
                <ListItemText primary={item.text} />
              </ListItemButton>
            </ListItem>
          ))}
        </List>
        <Divider />
        <Box sx={{ mt: 'auto', p: 2 }}>
          <Typography variant="caption" color="text.secondary">
            Connected to Kite
          </Typography>
          <Typography variant="body2" color="text.primary">
            {user?.user_id}
          </Typography>
        </Box>
      </Drawer>
      
      <Main open={open}>
        <DrawerHeader />
        {children}
      </Main>
    </Box>
  );
};

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  return (
    <DashboardLayout>
      <Box>
        <Typography variant="h4" gutterBottom>
          Welcome back, {user?.user_shortname || user?.user_name}!
        </Typography>
        
        <Typography variant="body1" color="text.secondary" paragraph>
          Your Kite API dashboard is ready. Use the navigation menu to access different features:
        </Typography>

        <Box sx={{ mt: 4, display: 'grid', gap: 2, gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))' }}>
          <Box sx={{ p: 3, border: 1, borderColor: 'divider', borderRadius: 2 }}>
            <HoldingsIcon color="primary" sx={{ mb: 1 }} />
            <Typography variant="h6">Holdings</Typography>
            <Typography variant="body2" color="text.secondary">
              View your current stock holdings and portfolio
            </Typography>
          </Box>

          <Box sx={{ p: 3, border: 1, borderColor: 'divider', borderRadius: 2 }}>
            <ChartsIcon color="primary" sx={{ mb: 1 }} />
            <Typography variant="h6">Charts</Typography>
            <Typography variant="body2" color="text.secondary">
              Analyze market data with interactive charts
            </Typography>
          </Box>

          <Box sx={{ p: 3, border: 1, borderColor: 'divider', borderRadius: 2 }}>
            <DownloadIcon color="primary" sx={{ mb: 1 }} />
            <Typography variant="h6">Historical Data</Typography>
            <Typography variant="body2" color="text.secondary">
              Download historical market data for analysis
            </Typography>
          </Box>
        </Box>

        {user && (
          <Box sx={{ mt: 4, p: 3, bgcolor: 'background.paper', borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom>
              Account Information
            </Typography>
            <Box sx={{ display: 'grid', gap: 1, gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>
              <Box>
                <Typography variant="caption" color="text.secondary">User ID</Typography>
                <Typography variant="body2">{user.user_id}</Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">User Type</Typography>
                <Typography variant="body2">{user.user_type}</Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">Broker</Typography>
                <Typography variant="body2">{user.broker}</Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">Exchanges</Typography>
                <Typography variant="body2">{user.exchanges?.join(', ')}</Typography>
              </Box>
            </Box>
          </Box>
        )}
      </Box>
    </DashboardLayout>
  );
};

export default Dashboard;
