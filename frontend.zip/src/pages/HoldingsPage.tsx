import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Alert,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Button,
} from '@mui/material';
import { Refresh } from '@mui/icons-material';
import { styled } from '@mui/material/styles';
import { api } from '../contexts/AuthContext';

const StyledTableContainer = styled(TableContainer)(({ theme }) => ({
  marginTop: theme.spacing(2),
  '& .MuiTableCell-head': {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.primary.contrastText,
    fontWeight: 600,
  },
}));

const ProfitChip = styled(Chip)<{ profit: number }>(({ theme, profit }) => ({
  fontWeight: 'bold',
  color: profit >= 0 ? theme.palette.success.contrastText : theme.palette.error.contrastText,
  backgroundColor: profit >= 0 ? theme.palette.success.main : theme.palette.error.main,
}));

interface Holding {
  tradingsymbol: string;
  exchange: string;
  instrument_token: number;
  isin: string;
  product: string;
  price: number;
  quantity: number;
  used_quantity: number;
  t1_quantity: number;
  realised_quantity: number;
  authorised_quantity: number;
  authorised_date: string | null;
  opening_quantity: number;
  collateral_quantity: number;
  collateral_type: string | null;
  discrepancy: boolean;
  average_price: number;
  last_price: number;
  close_price: number;
  pnl: number;
  day_change: number;
  day_change_percentage: number;
}

interface HoldingsData {
  net: number;
  total: number;
  holdings: Holding[];
}

const HoldingsPage: React.FC = () => {
  const [holdingsData, setHoldingsData] = useState<HoldingsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');

  const fetchHoldings = async () => {
    try {
      setLoading(true);
      setError('');
      const response = await api.get('/holdings/');
      setHoldingsData(response.data.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to fetch holdings');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHoldings();
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatPercentage = (percentage: number) => {
    return `${percentage >= 0 ? '+' : ''}${percentage.toFixed(2)}%`;
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 400 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box>
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
        <Button variant="contained" onClick={fetchHoldings} startIcon={<Refresh />}>
          Retry
        </Button>
      </Box>
    );
  }

  if (!holdingsData) {
    return (
      <Alert severity="info">
        No holdings data available
      </Alert>
    );
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" gutterBottom>
          Holdings
        </Typography>
        <Button
          variant="outlined"
          onClick={fetchHoldings}
          startIcon={<Refresh />}
          disabled={loading}
        >
          Refresh
        </Button>
      </Box>

      {/* Portfolio Summary */}
      <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', mb: 4 }}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Total Portfolio Value
            </Typography>
            <Typography variant="h4" color="primary">
              {formatCurrency(holdingsData.total)}
            </Typography>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Net P&L
            </Typography>
            <Typography 
              variant="h4" 
              color={holdingsData.net >= 0 ? 'success.main' : 'error.main'}
            >
              {formatCurrency(holdingsData.net)}
            </Typography>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Total Holdings
            </Typography>
            <Typography variant="h4" color="info.main">
              {holdingsData.holdings.length}
            </Typography>
          </CardContent>
        </Card>
      </Box>

      {/* Holdings Table */}
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Holdings Details
          </Typography>
          
          <StyledTableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Symbol</TableCell>
                  <TableCell>Exchange</TableCell>
                  <TableCell align="right">Quantity</TableCell>
                  <TableCell align="right">Avg Price</TableCell>
                  <TableCell align="right">LTP</TableCell>
                  <TableCell align="right">Current Value</TableCell>
                  <TableCell align="right">P&L</TableCell>
                  <TableCell align="right">Day Change</TableCell>
                  <TableCell>Product</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {holdingsData.holdings.map((holding, index) => (
                  <TableRow key={index}>
                    <TableCell>
                      <Typography variant="body2" fontWeight="medium">
                        {holding.tradingsymbol}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {holding.isin}
                      </Typography>
                    </TableCell>
                    <TableCell>{holding.exchange}</TableCell>
                    <TableCell align="right">{holding.quantity}</TableCell>
                    <TableCell align="right">{formatCurrency(holding.average_price)}</TableCell>
                    <TableCell align="right">{formatCurrency(holding.last_price)}</TableCell>
                    <TableCell align="right">
                      {formatCurrency(holding.last_price * holding.quantity)}
                    </TableCell>
                    <TableCell align="right">
                      <ProfitChip
                        label={formatCurrency(holding.pnl)}
                        profit={holding.pnl}
                        size="small"
                      />
                    </TableCell>
                    <TableCell align="right">
                      <ProfitChip
                        label={formatPercentage(holding.day_change_percentage)}
                        profit={holding.day_change}
                        size="small"
                      />
                    </TableCell>
                    <TableCell>{holding.product}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </StyledTableContainer>
        </CardContent>
      </Card>
    </Box>
  );
};

export default HoldingsPage;
