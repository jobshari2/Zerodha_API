import React, { useState } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  TextField,
  Button,
  Alert,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  IconButton,
  Tooltip,
  Chip,
} from '@mui/material';
import {
  Search,
  TrendingUp,
  Refresh,
  Download,
  ZoomIn,
  ZoomOut,
} from '@mui/icons-material';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
} from 'recharts';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { styled } from '@mui/material/styles';
import { api } from '../contexts/AuthContext';

const StyledCard = styled(Card)(({ theme }) => ({
  marginBottom: theme.spacing(3),
}));

const ChartContainer = styled(Box)(({ theme }) => ({
  height: '500px',
  width: '100%',
  marginTop: theme.spacing(2),
}));

interface CandlestickData {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

const CustomCandlestick: React.FC<{ data: any }> = ({ data }) => {
  if (!data || data.length === 0) return null;

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="date" 
          tick={{ fontSize: 12 }}
          tickFormatter={(value) => new Date(value).toLocaleDateString()}
        />
        <YAxis 
          domain={['dataMin - 1', 'dataMax + 1']}
          tick={{ fontSize: 12 }}
          tickFormatter={(value) => `₹${value.toFixed(2)}`}
        />
        <RechartsTooltip 
          labelFormatter={(value) => new Date(value).toLocaleDateString()}
          formatter={(value: any, name: string) => [`₹${value.toFixed(2)}`, name]}
        />
        <Line 
          type="monotone" 
          dataKey="open" 
          stroke="#2196f3" 
          strokeWidth={2}
          name="Open"
          dot={false}
        />
        <Line 
          type="monotone" 
          dataKey="high" 
          stroke="#4caf50" 
          strokeWidth={2}
          name="High"
          dot={false}
        />
        <Line 
          type="monotone" 
          dataKey="low" 
          stroke="#f44336" 
          strokeWidth={2}
          name="Low"
          dot={false}
        />
        <Line 
          type="monotone" 
          dataKey="close" 
          stroke="#ff9800" 
          strokeWidth={3}
          name="Close"
          dot={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
};

const ChartsPage: React.FC = () => {
  const [instrumentToken, setInstrumentToken] = useState<string>('');
  const [symbol, setSymbol] = useState<string>('');
  const [fromDate, setFromDate] = useState<Date | null>(new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)); // 30 days ago
  const [toDate, setToDate] = useState<Date | null>(new Date());
  const [interval, setInterval] = useState<string>('day');
  const [chartData, setChartData] = useState<CandlestickData[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');
  const [chartType, setChartType] = useState<'line' | 'area' | 'candlestick'>('line');

  const intervals = [
    { value: 'minute', label: '1 Minute' },
    { value: '3minute', label: '3 Minutes' },
    { value: '5minute', label: '5 Minutes' },
    { value: '15minute', label: '15 Minutes' },
    { value: '30minute', label: '30 Minutes' },
    { value: '60minute', label: '1 Hour' },
    { value: 'day', label: 'Daily' },
  ];

  const handleSearch = async () => {
    if (!instrumentToken || !fromDate || !toDate) {
      setError('Please fill all required fields');
      return;
    }

    try {
      setLoading(true);
      setError('');
      setSuccess('');

      const response = await api.get('/historical/data', {
        params: {
          instrument_token: parseInt(instrumentToken),
          from_date: fromDate.toISOString().split('T')[0],
          to_date: toDate.toISOString().split('T')[0],
          interval: interval,
        }
      });

      const data = response.data.data;
      if (data && data.length > 0) {
        // Transform the data for chart display
        const transformedData = data.map((item: any) => ({
          date: item.date,
          open: parseFloat(item.open),
          high: parseFloat(item.high),
          low: parseFloat(item.low),
          close: parseFloat(item.close),
          volume: item.volume ? parseInt(item.volume) : 0,
        }));

        setChartData(transformedData);
        setSuccess(`Loaded ${transformedData.length} data points`);
      } else {
        setError('No data found for the selected criteria');
      }
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to fetch chart data');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadData = async () => {
    if (chartData.length === 0) {
      setError('No chart data to download');
      return;
    }

    try {
      // Convert chart data to CSV
      const headers = ['Date', 'Open', 'High', 'Low', 'Close', 'Volume'];
      const csvContent = [
        headers.join(','),
        ...chartData.map(row => [
          row.date,
          row.open,
          row.high,
          row.low,
          row.close,
          row.volume || 0
        ].join(','))
      ].join('\n');

      // Create and download the file
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${symbol || instrumentToken}_${interval}_${fromDate?.toISOString().split('T')[0]}_to_${toDate?.toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      setSuccess('Chart data downloaded successfully!');
    } catch (err) {
      setError('Failed to download chart data');
    }
  };

  const renderChart = () => {
    if (chartData.length === 0) {
      return (
        <Box sx={{ 
          display: 'flex', 
          justifyContent: 'center', 
          alignItems: 'center', 
          height: '300px',
          backgroundColor: '#f5f5f5',
          borderRadius: 1
        }}>
          <Typography variant="h6" color="text.secondary">
            No chart data available. Search for an instrument to display charts.
          </Typography>
        </Box>
      );
    }

    switch (chartType) {
      case 'area':
        return (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => new Date(value).toLocaleDateString()}
              />
              <YAxis 
                domain={['dataMin - 1', 'dataMax + 1']}
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => `₹${value.toFixed(2)}`}
              />
              <RechartsTooltip 
                labelFormatter={(value) => new Date(value).toLocaleDateString()}
                formatter={(value: any) => [`₹${value.toFixed(2)}`, 'Close Price']}
              />
              <Area 
                type="monotone" 
                dataKey="close" 
                stroke="#2196f3" 
                fill="#2196f3" 
                fillOpacity={0.3}
              />
            </AreaChart>
          </ResponsiveContainer>
        );
      
      case 'candlestick':
        return <CustomCandlestick data={chartData} />;
      
      case 'line':
      default:
        return (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => new Date(value).toLocaleDateString()}
              />
              <YAxis 
                domain={['dataMin - 1', 'dataMax + 1']}
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => `₹${value.toFixed(2)}`}
              />
              <RechartsTooltip 
                labelFormatter={(value) => new Date(value).toLocaleDateString()}
                formatter={(value: any) => [`₹${value.toFixed(2)}`, 'Close Price']}
              />
              <Line 
                type="monotone" 
                dataKey="close" 
                stroke="#2196f3" 
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        );
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box>
        <Typography variant="h4" gutterBottom>
          Interactive Charts
        </Typography>

        <Typography variant="body1" color="text.secondary" paragraph>
          Professional trading charts with multiple timeframes and chart types
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
            {error}
          </Alert>
        )}

        {success && (
          <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess('')}>
            {success}
          </Alert>
        )}

        {/* Search Controls */}
        <StyledCard>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Chart Configuration
            </Typography>
            
            <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', mb: 3 }}>
              <TextField
                label="Instrument Token"
                value={instrumentToken}
                onChange={(e) => setInstrumentToken(e.target.value)}
                placeholder="e.g., 738561"
                type="number"
                fullWidth
              />

              <TextField
                label="Symbol Name (Optional)"
                value={symbol}
                onChange={(e) => setSymbol(e.target.value)}
                placeholder="e.g., RELIANCE"
                fullWidth
              />

              <DatePicker
                label="From Date"
                value={fromDate}
                onChange={setFromDate}
                slotProps={{ textField: { fullWidth: true } }}
              />

              <DatePicker
                label="To Date"
                value={toDate}
                onChange={setToDate}
                slotProps={{ textField: { fullWidth: true } }}
              />

              <FormControl fullWidth>
                <InputLabel>Interval</InputLabel>
                <Select
                  value={interval}
                  label="Interval"
                  onChange={(e) => setInterval(e.target.value)}
                >
                  {intervals.map((item) => (
                    <MenuItem key={item.value} value={item.value}>
                      {item.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              <FormControl fullWidth>
                <InputLabel>Chart Type</InputLabel>
                <Select
                  value={chartType}
                  label="Chart Type"
                  onChange={(e) => setChartType(e.target.value as any)}
                >
                  <MenuItem value="line">Line Chart</MenuItem>
                  <MenuItem value="area">Area Chart</MenuItem>
                  <MenuItem value="candlestick">Candlestick Chart</MenuItem>
                </Select>
              </FormControl>
            </Box>

            <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
              <Button
                variant="contained"
                onClick={handleSearch}
                disabled={loading}
                startIcon={loading ? <CircularProgress size={20} /> : <Search />}
              >
                {loading ? 'Loading...' : 'Load Chart Data'}
              </Button>

              <Button
                variant="outlined"
                onClick={handleDownloadData}
                disabled={chartData.length === 0}
                startIcon={<Download />}
              >
                Download Data
              </Button>

              <Button
                variant="outlined"
                onClick={() => {
                  setChartData([]);
                  setError('');
                  setSuccess('');
                }}
                startIcon={<Refresh />}
              >
                Clear Chart
              </Button>

              {chartData.length > 0 && (
                <Chip 
                  label={`${chartData.length} data points`} 
                  color="primary" 
                  variant="outlined" 
                />
              )}
            </Box>
          </CardContent>
        </StyledCard>

        {/* Chart Display */}
        <StyledCard>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                {symbol || instrumentToken ? `${symbol || instrumentToken} Chart` : 'Chart Display'}
              </Typography>
              
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Tooltip title="Zoom In">
                  <IconButton size="small">
                    <ZoomIn />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Zoom Out">
                  <IconButton size="small">
                    <ZoomOut />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Trend Analysis">
                  <IconButton size="small">
                    <TrendingUp />
                  </IconButton>
                </Tooltip>
              </Box>
            </Box>

            <ChartContainer>
              {renderChart()}
            </ChartContainer>

            {chartData.length > 0 && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="body2" color="text.secondary">
                  <strong>Chart Info:</strong> {chartType.charAt(0).toUpperCase() + chartType.slice(1)} chart showing {interval} interval data 
                  from {fromDate?.toLocaleDateString()} to {toDate?.toLocaleDateString()}
                </Typography>
              </Box>
            )}
          </CardContent>
        </StyledCard>

        {/* Chart Analytics */}
        {chartData.length > 0 && (
          <StyledCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Chart Analytics
              </Typography>
              
              <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle2" color="text.secondary">
                      Highest Price
                    </Typography>
                    <Typography variant="h5" color="success.main">
                      ₹{Math.max(...chartData.map(d => d.high)).toFixed(2)}
                    </Typography>
                  </CardContent>
                </Card>

                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle2" color="text.secondary">
                      Lowest Price
                    </Typography>
                    <Typography variant="h5" color="error.main">
                      ₹{Math.min(...chartData.map(d => d.low)).toFixed(2)}
                    </Typography>
                  </CardContent>
                </Card>

                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle2" color="text.secondary">
                      Latest Close
                    </Typography>
                    <Typography variant="h5" color="primary.main">
                      ₹{chartData[chartData.length - 1]?.close.toFixed(2)}
                    </Typography>
                  </CardContent>
                </Card>

                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle2" color="text.secondary">
                      Price Change
                    </Typography>
                    <Typography 
                      variant="h5" 
                      color={
                        chartData[chartData.length - 1]?.close > chartData[0]?.open 
                          ? 'success.main' 
                          : 'error.main'
                      }
                    >
                      {chartData.length > 1 ? 
                        `${((chartData[chartData.length - 1]?.close - chartData[0]?.open) / chartData[0]?.open * 100).toFixed(2)}%`
                        : 'N/A'
                      }
                    </Typography>
                  </CardContent>
                </Card>
              </Box>
            </CardContent>
          </StyledCard>
        )}
      </Box>
    </LocalizationProvider>
  );
};

export default ChartsPage;
