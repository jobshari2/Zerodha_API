import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  TextField,
  Button,
  Alert,
  CircularProgress,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tabs,
  Tab,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Checkbox,
  FormControlLabel,
} from '@mui/material';
import {
  Download,
  GetApp,
  Refresh,
  Delete,
  Visibility,
  Add,
  Remove,
  CloudDownload,
  Search,
} from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { styled } from '@mui/material/styles';
import { api } from '../contexts/AuthContext';

const StyledCard = styled(Card)(({ theme }) => ({
  marginBottom: theme.spacing(3),
}));

interface SavedFile {
  filename: string;
  filepath: string;
  symbol: string;
  from_date: string;
  to_date: string;
  interval: string;
  size_bytes: number;
  created_at: string;
  modified_at: string;
}

interface BulkDownloadItem {
  id: string;
  instrumentToken: string;
  symbol: string;
  exchange: string;
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const HistoricalDataPage: React.FC = () => {
  const [tabValue, setTabValue] = useState(0);
  
  // Single download states
  const [instrumentToken, setInstrumentToken] = useState<string>('');
  const [fromDate, setFromDate] = useState<Date | null>(null);
  const [toDate, setToDate] = useState<Date | null>(null);
  const [interval, setInterval] = useState<string>('day');
  const [continuous, setContinuous] = useState<boolean>(false);
  const [oi, setOi] = useState<boolean>(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');

  // Bulk download states
  const [bulkItems, setBulkItems] = useState<BulkDownloadItem[]>([]);
  const [bulkFromDate, setBulkFromDate] = useState<Date | null>(null);
  const [bulkToDate, setBulkToDate] = useState<Date | null>(null);
  const [bulkInterval, setBulkInterval] = useState<string>('day');
  const [bulkContinuous, setBulkContinuous] = useState<boolean>(false);
  const [bulkOi, setBulkOi] = useState<boolean>(false);
  const [bulkLoading, setBulkLoading] = useState(false);
  const [newBulkSymbol, setNewBulkSymbol] = useState<string>('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);

  // File management states
  const [savedFiles, setSavedFiles] = useState<SavedFile[]>([]);
  const [filesLoading, setFilesLoading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<SavedFile | null>(null);
  const [previewDialog, setPreviewDialog] = useState(false);

  const intervals = [
    { value: 'minute', label: '1 Minute' },
    { value: '3minute', label: '3 Minutes' },
    { value: '5minute', label: '5 Minutes' },
    { value: '15minute', label: '15 Minutes' },
    { value: '30minute', label: '30 Minutes' },
    { value: '60minute', label: '1 Hour' },
    { value: 'day', label: 'Daily' },
  ];

  useEffect(() => {
    fetchSavedFiles();
  }, []);

  const fetchSavedFiles = async () => {
    try {
      setFilesLoading(true);
      const response = await api.get('/historical/saved-data');
      setSavedFiles(response.data.data.files);
    } catch (err: any) {
      console.error('Error fetching saved files:', err);
    } finally {
      setFilesLoading(false);
    }
  };

  // Single download functionality
  const handleDownload = async () => {
    if (!instrumentToken || !fromDate || !toDate) {
      setError('Please fill all required fields');
      return;
    }

    try {
      setLoading(true);
      setError('');
      setSuccess('');

      await api.post('/historical/download', {
        instrument_token: parseInt(instrumentToken),
        from_date: fromDate.toISOString().split('T')[0],
        to_date: toDate.toISOString().split('T')[0],
        interval: interval,
        continuous: continuous,
        oi: oi,
      });

      setSuccess('Historical data downloaded successfully!');
      fetchSavedFiles(); // Refresh the saved files list
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to download historical data');
    } finally {
      setLoading(false);
    }
  };

  // Bulk download functionality
  const handleBulkDownload = async () => {
    if (bulkItems.length === 0) {
      setError('Please add instruments to download');
      return;
    }

    try {
      setBulkLoading(true);
      setError('');
      setSuccess('');

      // Prepare the request data
      const requests = bulkItems.map(item => ({
        instrument_token: parseInt(item.instrumentToken),
        from_date: bulkFromDate?.toISOString().split('T')[0],
        to_date: bulkToDate?.toISOString().split('T')[0],
        interval: bulkInterval,
        continuous: bulkContinuous,
        oi: bulkOi,
      }));

      // Perform bulk download
      await api.post('/historical/bulk-download', { requests });

      setSuccess('Bulk download started successfully!');
      // Optionally, you can refresh the saved files list or provide a link to download the zip file
    } catch (err: any) {
      setError('Failed to start bulk download');
    } finally {
      setBulkLoading(false);
    }
  };

  const handleDeleteFile = async (filename: string) => {
    try {
      await api.delete(`/historical/saved-data/${filename}`);
      setSuccess('File deleted successfully');
      fetchSavedFiles();
    } catch (err: any) {
      setError('Failed to delete file');
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Bulk actions
  const handleAddToBulk = () => {
    // Add the current instrument to the bulk items
    setBulkItems([...bulkItems, {
      id: newBulkSymbol,
      instrumentToken: newBulkSymbol,
      symbol: newBulkSymbol,
      exchange: 'NSE', // Default exchange, you can modify this
    }]);

    setNewBulkSymbol('');
  };

  const handleRemoveFromBulk = (id: string) => {
    // Remove the item from bulk items
    setBulkItems(bulkItems.filter(item => item.id !== id));
  };

  // Search functionality
  const handleSearch = async () => {
    if (!newBulkSymbol) return;

    setSearchLoading(true);

    try {
      const response = await api.get(`/search/instruments`, {
        params: { query: newBulkSymbol },
      });

      setSearchResults(response.data.data);
    } catch (err: any) {
      console.error('Error fetching search results:', err);
    } finally {
      setSearchLoading(false);
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box>
        <Typography variant="h4" gutterBottom>
          Historical Data Download
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
            {error}
          </Alert>
        )}

        {success && (
          <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess('')}>
            {success}
          </Alert>
        )}

        {/* Download Tabs */}
        <Paper sx={{ mb: 3 }}>
          <Tabs
            value={tabValue}
            onChange={(e, newValue) => setTabValue(newValue)}
            indicatorColor="primary"
            textColor="primary"
            variant="fullWidth"
          >
            <Tab label="Single Download" />
            <Tab label="Bulk Download" />
          </Tabs>
        </Paper>

        {/* Single Download Form */}
        <TabPanel value={tabValue} index={0}>
          <StyledCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Download New Data
              </Typography>

              <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', mb: 3 }}>
                <TextField
                  label="Instrument Token"
                  value={instrumentToken}
                  onChange={(e) => setInstrumentToken(e.target.value)}
                  placeholder="e.g., 738561"
                  type="number"
                  fullWidth
                />

                <DatePicker
                  label="From Date"
                  value={fromDate}
                  onChange={setFromDate}
                  slotProps={{ textField: { fullWidth: true } }}
                />

                <DatePicker
                  label="To Date"
                  value={toDate}
                  onChange={setToDate}
                  slotProps={{ textField: { fullWidth: true } }}
                />

                <FormControl fullWidth>
                  <InputLabel>Interval</InputLabel>
                  <Select
                    value={interval}
                    label="Interval"
                    onChange={(e) => setInterval(e.target.value)}
                  >
                    {intervals.map((item) => (
                      <MenuItem key={item.value} value={item.value}>
                        {item.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Box>

              <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', mb: 2 }}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={continuous}
                      onChange={(e) => setContinuous(e.target.checked)}
                    />
                  }
                  label="Continuous (Adjust for splits and dividends)"
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={oi}
                      onChange={(e) => setOi(e.target.checked)}
                    />
                  }
                  label="Include Open Interest (OI)"
                />
              </Box>

              <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
                <Button
                  variant="contained"
                  onClick={handleDownload}
                  disabled={loading}
                  startIcon={loading ? <CircularProgress size={20} /> : <Download />}
                >
                  {loading ? 'Downloading...' : 'Download Data'}
                </Button>

                <Typography variant="body2" color="text.secondary">
                  Data will be saved locally and listed below
                </Typography>
              </Box>
            </CardContent>
          </StyledCard>
        </TabPanel>

        {/* Bulk Download Form */}
        <TabPanel value={tabValue} index={1}>
          <StyledCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Bulk Download
              </Typography>

              <Box sx={{ mb: 2 }}>
                <TextField
                  label="Add Instrument Token"
                  value={newBulkSymbol}
                  onChange={(e) => setNewBulkSymbol(e.target.value)}
                  placeholder="e.g., 738561"
                  type="number"
                  fullWidth
                  onKeyDown={(e) => e.key === 'Enter' && handleAddToBulk()}
                />
              </Box>

              <Button
                variant="outlined"
                onClick={handleSearch}
                disabled={searchLoading}
                startIcon={searchLoading ? <CircularProgress size={20} /> : <Search />}
                sx={{ mb: 2 }}
              >
                {searchLoading ? 'Searching...' : 'Search Instruments'}
              </Button>

              <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' } }}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle1" gutterBottom>
                      Search Results
                    </Typography>

                    <List>
                      {searchResults.map((result) => (
                        <ListItem key={result.id}>
                          <ListItemText
                            primary={result.symbol}
                            secondary={`Token: ${result.instrument_token}`}
                          />
                          <ListItemSecondaryAction>
                            <IconButton
                              edge="end"
                              onClick={() => {
                                setBulkItems([...bulkItems, {
                                  id: result.id,
                                  instrumentToken: result.instrument_token,
                                  symbol: result.symbol,
                                  exchange: result.exchange,
                                }]);
                                setSearchResults([]); // Clear results after adding
                              }}
                            >
                              <Add />
                            </IconButton>
                          </ListItemSecondaryAction>
                        </ListItem>
                      ))}
                    </List>
                  </CardContent>
                </Card>

                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle1" gutterBottom>
                      Selected for Bulk Download
                    </Typography>

                    <List>
                      {bulkItems.map((item) => (
                        <ListItem key={item.id}>
                          <ListItemText
                            primary={item.symbol}
                            secondary={`Token: ${item.instrumentToken}`}
                          />
                          <ListItemSecondaryAction>
                            <IconButton
                              edge="end"
                              onClick={() => handleRemoveFromBulk(item.id)}
                            >
                              <Remove />
                            </IconButton>
                          </ListItemSecondaryAction>
                        </ListItem>
                      ))}
                    </List>
                  </CardContent>
                </Card>
              </Box>

              <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', mt: 2 }}>
                <DatePicker
                  label="From Date"
                  value={bulkFromDate}
                  onChange={setBulkFromDate}
                  slotProps={{ textField: { fullWidth: true } }}
                />

                <DatePicker
                  label="To Date"
                  value={bulkToDate}
                  onChange={setBulkToDate}
                  slotProps={{ textField: { fullWidth: true } }}
                />

                <FormControl fullWidth>
                  <InputLabel>Interval</InputLabel>
                  <Select
                    value={bulkInterval}
                    label="Interval"
                    onChange={(e) => setBulkInterval(e.target.value)}
                  >
                    {intervals.map((item) => (
                      <MenuItem key={item.value} value={item.value}>
                        {item.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Box>

              <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', mt: 2, mb: 2 }}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={bulkContinuous}
                      onChange={(e) => setBulkContinuous(e.target.checked)}
                    />
                  }
                  label="Continuous (Adjust for splits and dividends)"
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={bulkOi}
                      onChange={(e) => setBulkOi(e.target.checked)}
                    />
                  }
                  label="Include Open Interest (OI)"
                />
              </Box>

              <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
                <Button
                  variant="contained"
                  onClick={handleBulkDownload}
                  disabled={bulkLoading}
                  startIcon={bulkLoading ? <CircularProgress size={20} /> : <CloudDownload />}
                >
                  {bulkLoading ? 'Processing...' : 'Start Bulk Download'}
                </Button>

                <Typography variant="body2" color="text.secondary">
                  All selected data will be downloaded as a zip file
                </Typography>
              </Box>
            </CardContent>
          </StyledCard>
        </TabPanel>

        {/* Saved Files */}
        <StyledCard>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Saved Files
              </Typography>
              <Button
                variant="outlined"
                onClick={fetchSavedFiles}
                disabled={filesLoading}
                startIcon={<Refresh />}
              >
                Refresh
              </Button>
            </Box>

            {filesLoading ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                <CircularProgress />
              </Box>
            ) : savedFiles.length === 0 ? (
              <Alert severity="info">
                No saved files found. Download some historical data to see them here.
              </Alert>
            ) : (
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Symbol</TableCell>
                      <TableCell>Date Range</TableCell>
                      <TableCell>Interval</TableCell>
                      <TableCell>File Size</TableCell>
                      <TableCell>Created</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {savedFiles.map((file, index) => (
                      <TableRow key={index}>
                        <TableCell>
                          <Typography variant="body2" fontWeight="medium">
                            {file.symbol}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {file.filename}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={`${file.from_date} to ${file.to_date}`}
                            variant="outlined"
                            size="small"
                          />
                        </TableCell>
                        <TableCell>{file.interval}</TableCell>
                        <TableCell>{formatFileSize(file.size_bytes)}</TableCell>
                        <TableCell>{formatDate(file.created_at)}</TableCell>
                        <TableCell>
                          <Box sx={{ display: 'flex', gap: 1 }}>
                            <Button
                              size="small"
                              onClick={() => {
                                setSelectedFile(file);
                                setPreviewDialog(true);
                              }}
                              startIcon={<Visibility />}
                            >
                              View
                            </Button>
                            <Button
                              size="small"
                              href={`http://localhost:3000/api/historical/download-file/${file.filename}`}
                              startIcon={<GetApp />}
                            >
                              Download
                            </Button>
                            <Button
                              size="small"
                              color="error"
                              onClick={() => handleDeleteFile(file.filename)}
                              startIcon={<Delete />}
                            >
                              Delete
                            </Button>
                          </Box>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </CardContent>
        </StyledCard>

        {/* File Preview Dialog */}
        <Dialog
          open={previewDialog}
          onClose={() => setPreviewDialog(false)}
          maxWidth="md"
          fullWidth
        >
          <DialogTitle>
            File Preview: {selectedFile?.filename}
          </DialogTitle>
          <DialogContent>
            {selectedFile && (
              <Box>
                <Typography variant="body2" gutterBottom>
                  <strong>Symbol:</strong> {selectedFile.symbol}
                </Typography>
                <Typography variant="body2" gutterBottom>
                  <strong>Date Range:</strong> {selectedFile.from_date} to {selectedFile.to_date}
                </Typography>
                <Typography variant="body2" gutterBottom>
                  <strong>Interval:</strong> {selectedFile.interval}
                </Typography>
                <Typography variant="body2" gutterBottom>
                  <strong>File Size:</strong> {formatFileSize(selectedFile.size_bytes)}
                </Typography>
                <Typography variant="body2" gutterBottom>
                  <strong>Created:</strong> {formatDate(selectedFile.created_at)}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Use the download button to get the CSV file for further analysis.
                </Typography>
              </Box>
            )}
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setPreviewDialog(false)}>
              Close
            </Button>
            <Button
              variant="contained"
              href={selectedFile ? `http://localhost:3000/api/historical/download-file/${selectedFile.filename}` : '#'}
              startIcon={<GetApp />}
            >
              Download File
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </LocalizationProvider>
  );
};

export default HistoricalDataPage;
