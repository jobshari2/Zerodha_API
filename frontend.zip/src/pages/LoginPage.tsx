import React, { useState, useEffect, useCallback } from 'react';
import {
  Container,
  Paper,
  Box,
  Typography,
  Button,
  TextField,
  Alert,
  CircularProgress,
  Card,
  CardContent,
  Divider,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate, useLocation } from 'react-router-dom';

const StyledContainer = styled(Container)(({ theme }) => ({
  minHeight: '100vh',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
  padding: theme.spacing(2),
}));

const LoginCard = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  maxWidth: 480,
  width: '100%',
  borderRadius: theme.spacing(2),
  boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
}));

const LogoSection = styled(Box)(({ theme }) => ({
  textAlign: 'center',
  marginBottom: theme.spacing(3),
}));

const LoginPage: React.FC = () => {
  const { login, getLoginUrl, isLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  const [loginUrl, setLoginUrl] = useState<string>('');
  const [requestToken, setRequestToken] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [loadingLogin, setLoadingLogin] = useState(false);
  const [step, setStep] = useState<'initial' | 'redirect' | 'token'>('initial');

  const handleTokenLogin = useCallback(async (token: string) => {
    try {
      setLoadingLogin(true);
      setError('');
      await login(token);
      navigate('/dashboard');
    } catch (err) {
      setError('Login failed. Please try again.');
      setStep('initial');
      navigate('/login', { replace: true });
    } finally {
      setLoadingLogin(false);
    }
  }, [login, navigate]);

  const initializeLogin = useCallback(async () => {
    try {
      const url = await getLoginUrl();
      setLoginUrl(url);
      setStep('initial');
    } catch (err) {
      setError('Failed to initialize login. Please try again.');
    }
  }, [getLoginUrl]);

  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const token = urlParams.get('request_token');
    
    if (token) {
      setRequestToken(token);
      setStep('token');
      handleTokenLogin(token);
    } else {
      initializeLogin();
    }
  }, [location, handleTokenLogin, initializeLogin]);

  const handleKiteLogin = () => {
    if (loginUrl) {
      setStep('redirect');
      window.location.href = loginUrl;
    }
  };

  const handleManualTokenSubmit = () => {
    if (requestToken.trim()) {
      handleTokenLogin(requestToken.trim());
    }
  };

  if (step === 'redirect') {
    return (
      <StyledContainer>
        <LoginCard>
          <LogoSection>
            <TrendingUpIcon sx={{ fontSize: 48, color: 'primary.main', mb: 2 }} />
            <Typography variant="h4" gutterBottom>
              Zerodha Kite API
            </Typography>
          </LogoSection>
          
          <Box textAlign="center">
            <CircularProgress size={40} sx={{ mb: 2 }} />
            <Typography variant="body1" color="text.secondary">
              Redirecting to Kite login...
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              You will be redirected back after authentication
            </Typography>
          </Box>
        </LoginCard>
      </StyledContainer>
    );
  }

  if (step === 'token' && loadingLogin) {
    return (
      <StyledContainer>
        <LoginCard>
          <LogoSection>
            <TrendingUpIcon sx={{ fontSize: 48, color: 'primary.main', mb: 2 }} />
            <Typography variant="h4" gutterBottom>
              Zerodha Kite API
            </Typography>
          </LogoSection>
          
          <Box textAlign="center">
            <CircularProgress size={40} sx={{ mb: 2 }} />
            <Typography variant="body1" color="text.secondary">
              Completing login...
            </Typography>
          </Box>
        </LoginCard>
      </StyledContainer>
    );
  }

  return (
    <StyledContainer>
      <LoginCard>
        <LogoSection>
          <TrendingUpIcon sx={{ fontSize: 48, color: 'primary.main', mb: 2 }} />
          <Typography variant="h4" gutterBottom>
            Zerodha Kite API
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Connect to your Kite account to get started
          </Typography>
        </LogoSection>

        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}

        <Card variant="outlined" sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Step 1: Kite Authentication
            </Typography>
            <Typography variant="body2" color="text.secondary" paragraph>
              Click the button below to login with your Kite credentials. You'll be redirected 
              to Zerodha's secure login page.
            </Typography>
            <Button
              variant="contained"
              size="large"
              fullWidth
              onClick={handleKiteLogin}
              disabled={!loginUrl || isLoading}
              sx={{ mt: 2 }}
            >
              {isLoading ? <CircularProgress size={24} /> : 'Login with Kite'}
            </Button>
          </CardContent>
        </Card>

        <Divider sx={{ my: 2 }}>
          <Typography variant="body2" color="text.secondary">
            OR
          </Typography>
        </Divider>

        <Card variant="outlined">
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Step 2: Manual Token Entry
            </Typography>
            <Typography variant="body2" color="text.secondary" paragraph>
              If you already have a request token, you can enter it manually below.
            </Typography>
            <TextField
              fullWidth
              label="Request Token"
              value={requestToken}
              onChange={(e) => setRequestToken(e.target.value)}
              placeholder="Enter your request token"
              margin="normal"
            />
            <Button
              variant="outlined"
              size="large"
              fullWidth
              onClick={handleManualTokenSubmit}
              disabled={!requestToken.trim() || loadingLogin}
              sx={{ mt: 2 }}
            >
              {loadingLogin ? <CircularProgress size={24} /> : 'Complete Login'}
            </Button>
          </CardContent>
        </Card>

        <Box mt={3} textAlign="center">
          <Typography variant="body2" color="text.secondary">
            Powered by Kite Connect API
          </Typography>
        </Box>
      </LoginCard>
    </StyledContainer>
  );
};

export default LoginPage;
